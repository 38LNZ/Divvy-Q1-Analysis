library(tidyverse)
library(skimr)
library(janitor)
library(naniar)

##----------##
## PREPARAR
##----------##

## IMPORTAMOS VIAJES DEL PRIMER CUATRIMESTRE DEL 2020
Divvy_Trips_2020_Q1.csv <- read.csv('C:\\Users\\Usuario\\Desktop\\tesis\\tesis_Cyclistic\\BBDD_sin_preparar\\Divvy_Trips_2020_Q1.csv')
view(head(Divvy_Trips_2020_Q1.csv))

## RENOMBRAMOS ALS COLUMNAS
Divvy_Trips_2020_Q1.csv <- Divvy_Trips_2020_Q1.csv %>% 
  rename(
    viaje_id = ride_id,
    tipo_bici = rideable_type,
    fecha_hora_inicio = started_at,
    fecha_hora_fin = ended_at,
    estacion_inicio_nombre = start_station_name,
    estacion_inicio_id = start_station_id,
    estacion_fin_nombre = end_station_name,
    estacion_fin_id = end_station_id,
    inicio_lat = start_lat,
    inicio_lng = start_lng,
    fin_lat = end_lat,
    fin_lng = end_lng,
    tipo_usuario = member_casual
  )

## LIMPIAMOS CARACTERES INNECESARIOS
Divvy_Trips_2020_Q1.csv <- Divvy_Trips_2020_Q1.csv %>% 
  clean_names()

## QUITAMOS TODOS LOS DATOS DUPLICADOS
Divvy_Trips_2020_Q1.csv <- Divvy_Trips_2020_Q1.csv %>% 
  distinct()

## MODIFICAR LOS DATOS FALTANTES
## Corroboramos si hay datos faltantes
gg_miss_var(Divvy_Trips_2020_Q1.csv)

## Eliminamos las filas donde faltan datos 
Divvy_Trips_2020_Q1.csv <- Divvy_Trips_2020_Q1.csv %>% 
  drop_na()
## Corroboramos nuevamene
gg_miss_var(Divvy_Trips_2020_Q1.csv)

## GUARDAMOS LA BASE DE DATOS PREPARADA
write.csv(Divvy_Trips_2020_Q1.csv, 'C:\\Users\\Usuario\\Desktop\\tesis\\tesis_Cyclistic\\BBDD_preparada\\Divvy_Trips_2020_Q1.limpio.csv', row.names =  FALSE)
