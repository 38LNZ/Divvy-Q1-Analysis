library(tidyverse)
library(skimr)
library(janitor)
library(naniar)
##----------##
## PREPARAR
##----------##

## IMPORTAMOS VIAJES DEL PRIMER CUATRIMESTRE DEL 2019
Divvy_Trips_2019_Q1.csv <- read_csv('C:\\Users\\Usuario\\Desktop\\tesis\\tesis_Cyclistic\\BBDD_sin_preparar\\Divvy_Trips_2019_Q1.csv')
skim_without_charts(Divvy_Trips_2019_Q1.csv)
view(head(Divvy_Trips_2019_Q1.csv))

## RENOMBRAMOS ALS COLUMNAS
Divvy_Trips_2019_Q1.csv <- Divvy_Trips_2019_Q1.csv %>% 
  rename(
    viaje_id=trip_id,
    fecha_hora_inicio =start_time,
    fecha_hora_fin = end_time,
    bici_id = bikeid,
    duracion_seg = tripduration,
    estacion_inicio_id = from_station_id,
    estacion_inicio_nombre = from_station_name,
    estacion_fin_id = to_station_id,
    estacion_fin_nombre = to_station_name,
    tipo_usuario = usertype,
    genero = gender,
    año_nac = birthyear
  )

## LIMPIAMOS CARACTERES INNECESARIOS
Divvy_Trips_2019_Q1.csv <- Divvy_Trips_2019_Q1.csv %>% 
  clean_names()

## QUITAMOS TODOS LOS DATOS DUPLICADOS
Divvy_Trips_2019_Q1.csv <- Divvy_Trips_2019_Q1.csv %>%
  distinct()

## MODIFICAR LOS DATOS FALTANTES
## Corroboramos si hay datos faltantes
gg_miss_var(Divvy_Trips_2019_Q1.csv)

## Reemplazamos numerico con media y cualitativos con "Desconocidos"
Divvy_Trips_2019_Q1.csv <- Divvy_Trips_2019_Q1.csv %>% 
  mutate(
    ano_nac = ifelse(is.na(ano_nac), mean(ano_nac, na.rm = TRUE), ano_nac),
    genero = ifelse(is.na(genero), "Desconocido", genero)
  )
## Corroboramos nuevamente
gg_miss_var(Divvy_Trips_2019_Q1.csv)

## GUARDAMOS LA BASE DE DATOS PREPARADA
write.csv(Divvy_Trips_2019_Q1.csv, 'C:\\Users\\Usuario\\Desktop\\tesis\\tesis_Cyclistic\\BBDD_preparada\\Divvy_Trips_2019_Q1.limpio.csv', row.names = FALSE)
