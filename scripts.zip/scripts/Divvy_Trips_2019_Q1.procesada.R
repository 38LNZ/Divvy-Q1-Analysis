library(tidyverse)
library(lubridate)

Divvy_Trips_2019_Q1.limpio.csv <- read.csv('C:\\Users\\Usuario\\Desktop\\tesis\\tesis_Cyclistic\\BBDD_preparada\\Divvy_Trips_2019_Q1.limpio.csv')
view(head(Divvy_Trips_2019_Q1.limpio.csv))

## CREAMOS COLUMNAS NECESARIAS
## Duracion de viaje HH:MM:SS
Divvy_Trips_2019_Q1.limpio.csv <- Divvy_Trips_2019_Q1.limpio.csv %>% 
  mutate(
    duracion_hms = sprintf(
      "%02d:%02d:%02d",
      duracion_seg %/% 3600,
      (duracion_seg %% 3600) %/% 60,
      duracion_seg %% 60 
    )
  )
view(head(Divvy_Trips_2019_Q1.limpio.csv))

## Dia de semana nombre
Divvy_Trips_2019_Q1.limpio.csv <- Divvy_Trips_2019_Q1.limpio.csv %>% 
  mutate(
    dia_semana = wday(fecha_hora_inicio, label = TRUE, abbr = FALSE)
  )
view(head(Divvy_Trips_2019_Q1.limpio.csv))

## Guardamos BBDD nueva
write.csv(Divvy_Trips_2019_Q1.limpio.csv, 'C:\\Users\\Usuario\\Desktop\\tesis\\tesis_Cyclistic\\BBDD_procesada\\Divvy_Trips_2019_Q1.procesada.csv')
