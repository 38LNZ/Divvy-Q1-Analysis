library(tidyverse)

## Importamos los dataset
Divvy_Trips_2019_Q1.procesada.csv <-read.csv('C:\\Users\\Usuario\\Desktop\\tesis\\tesis_Cyclistic\\BBDD_procesada\\Divvy_Trips_2019_Q1.procesada.csv')
view(head(Divvy_Trips_2019_Q1.procesada.csv))
Divvy_Trips_2020_Q1.procesada.csv <-read.csv('C:\\Users\\Usuario\\Desktop\\tesis\\tesis_Cyclistic\\BBDD_procesada\\Divvy_Trips_2020_Q1.procesada.csv')
view(head(Divvy_Trips_2020_Q1.procesada.csv))
##Comprobamos la consistencia de las columnas
colnames(Divvy_Trips_2019_Q1.procesada.csv)
colnames(Divvy_Trips_2020_Q1.procesada.csv)

# SACAMOS LA MEDIA DE AMBOS CUATRIMESTRE
media_viaje_2019 <-mean(Divvy_Trips_2019_Q1.procesada.csv$duracion_seg)
print(media_viaje_2019)
media_viaje_2020 <-mean(Divvy_Trips_2020_Q1.procesada.csv$duracion_seg)
print(media_viaje_2020)
# Seleccionar columnas comunes
Colum_comunes <- intersect(names(Divvy_Trips_2019_Q1.procesada.csv), names(Divvy_Trips_2020_Q1.procesada.csv))

Divvy_Trips_2019_Q1.procesada.csv <- Divvy_Trips_2019_Q1.procesada.csv[, Colum_comunes]
Divvy_Trips_2020_Q1.procesada.csv <- Divvy_Trips_2020_Q1.procesada.csv[, Colum_comunes]

# Pasamo al mismo tipo e dato "viaje_id"
Divvy_Trips_2019_Q1.procesada.csv <- Divvy_Trips_2019_Q1.procesada.csv %>% 
  mutate(viaje_id = as.character(viaje_id))

Divvy_Trips_2020_Q1.procesada.csv <- Divvy_Trips_2020_Q1.procesada.csv %>% 
  mutate(viaje_id = as.character(viaje_id))

# Combinamos todo en un solo dataframe
Divvy_Trips_2019_2020_Q1.csv <- bind_rows(Divvy_Trips_2019_Q1.procesada.csv, Divvy_Trips_2020_Q1.procesada.csv)
view(head(Divvy_Trips_2019_2020_Q1.csv))
view(Divvy_Trips_2019_2020_Q1.csv)

# Eliminamos viajes con duracion menor a cero
Divvy_Trips_2019_2020_Q1.csv <- Divvy_Trips_2019_2020_Q1.csv %>% 
  filter(duracion_seg > 0)

# Analisis descriptivo

media_viaje <-mean(Divvy_Trips_2019_2020_Q1.csv$duracion_seg)
print(media_viaje)
max_viaje <- max(Divvy_Trips_2019_2020_Q1.csv$duracion_seg)
min_viaje <- min(Divvy_Trips_2019_2020_Q1.csv$duracion_seg)

# Exportamos el csv para analisis posterior
write.csv(Divvy_Trips_2019_2020_Q1.csv,'C:\\Users\\Usuario\\Desktop\\tesis\\tesis_Cyclistic\\BBDD_analizada\\Divvy_Trips_2019_2020_Q1.csv')
