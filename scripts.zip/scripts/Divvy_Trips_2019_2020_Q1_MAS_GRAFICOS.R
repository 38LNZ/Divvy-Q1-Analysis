library(tidyverse)
library(ggplot2)
library(scales)

# Importamos csv
Divvy_Trips_2019_2020_Q1 <- read.csv('C:\\Users\\Usuario\\Desktop\\tesis\\tesis_Cyclistic\\BBDD_analizada\\Divvy_Trips_2019_2020_Q1.csv')
view(head(Divvy_Trips_2019_2020_Q1))
Divvy_Trips_2019_Q1 <- read.csv('C:\\Users\\Usuario\\Desktop\\tesis\\tesis_Cyclistic\\BBDD_procesada\\Divvy_Trips_2019_Q1.procesada.csv')
view(head(Divvy_Trips_2019_Q1))
Divvy_Trips_2020_Q1 <- read.csv('C:\\Users\\Usuario\\Desktop\\tesis\\tesis_Cyclistic\\BBDD_procesada\\Divvy_Trips_2020_Q1.procesada.csv')
#------------------
# CREAMOS GRAFICOS
#------------------

# 1ro - Grafico de torta
# A) 
viajes_por_dias_2019 <- Divvy_Trips_2019_Q1 %>% 
  group_by(dia_semana) %>% 
  summarise(cantidad_viajes = n())

ggplot(viajes_por_dias_2019, aes(x = "", y = cantidad_viajes, fill = dia_semana))+
  geom_col(width = 1)+
  coord_polar("y")+
  labs(title = "Cantidad de viajes por dia de la semana 2019", fill= "Dia")+
  theme_void()

# B)
viajes_por_dias_2020 <- Divvy_Trips_2020_Q1 %>% 
  group_by(dia_semana) %>% 
  summarise(cantidad_viajes = n())

ggplot(viajes_por_dias_2020, aes(x= "", y = cantidad_viajes, fill = dia_semana))+
  geom_col(width = 1)+
  coord_polar("y")+
  labs(title = "Cantidad de viajes por dia de la semana 2020", fill = "Dia")+
  theme_void()

# 2do - Grafico de barra
# A)
viajes_dia_tipo_usuario_1 <- Divvy_Trips_2019_Q1 %>% 
  mutate(tipo_usuario = case_when(
           tipo_usuario %in% c("Subscriber", "member")~"Miembro",
           tipo_usuario %in% c("Customer", "casual")~"Casual",
           TRUE ~ tipo_usuario)) %>% 
  group_by(dia_semana, tipo_usuario) %>% 
  summarise(cantidad_viajes = n(), .groups = "drop")

ggplot(viajes_dia_tipo_usuario_1, aes(x = dia_semana, y = cantidad_viajes, fill = tipo_usuario)) +
  geom_bar(stat = "identity", position = "dodge")+
  labs(title = "Viajes por dia segun tipo de usuario 2019", x="Dia de semana", y="Cantidad de viajes", fill="Tipo de usuario")+
  theme_minimal()+
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# B)
viajes_dia_tipo_usuario <- Divvy_Trips_2020_Q1 %>% 
  mutate(tipo_usuario = case_when(
    tipo_usuario %in% c("Subscriber", "member")~"Miembro",
    tipo_usuario %in% c("Customer", "casual")~"Casual",
    TRUE ~ tipo_usuario)) %>%
  group_by(dia_semana, tipo_usuario) %>% 
  summarise(cantidad_viajes = n(), .groups = "drop")

ggplot(viajes_dia_tipo_usuario, aes(x=dia_semana, y= cantidad_viajes, fill = tipo_usuario))+
  geom_bar(stat = "identity", position = "dodge")+
  labs(title = "Viajes por dia segun tipo de usuario 2020", x="Dia de semana", y="Tipo usuario")+
  theme_minimal()+
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

#Grafico de barra comparando uso por tipo de usuario en los diferentes cuatrimestres
# C)
comparacion_por_año_miembros <- Divvy_Trips_2019_2020_Q1 %>% 
  mutate(año = year(ymd_hms(fecha_hora_inicio)),
         tipo_usuario = case_when(
           tipo_usuario %in% c("Subscriber", "member")~"Miembro",
           tipo_usuario %in% c("Customer", "casual")~"Casual",
           TRUE ~ tipo_usuario
         )) %>% 
  group_by(año, tipo_usuario) %>% 
  summarise(cantidad_viajes = n(), .groups="drop")

ggplot(comparacion_por_año_miembros, aes(x=factor(año), y=cantidad_viajes, fill = tipo_usuario))+
  geom_bar(stat = "identity", position = "dodge")+
  labs(title = "Cantidad de viajes por año y tipo de usuario", x="Año", y="Cantidad de viajes", fill="Tipo de usuario")+
  scale_y_continuous(labels = label_number(accuracy = 1)) +
  theme_minimal()
#--------------------
#--------------------
#--------------------
# SACAMOS LA DIFERENCIA ENTRE LA CANTIDAD DE VIAJES TOTALES DEL 2019
# Y DEL 2020
Divvy_Trips_2019_2020_Q1 <- Divvy_Trips_2019_2020_Q1 %>% 
  mutate(año = year(ymd_hms(fecha_hora_inicio)))
         
cant_2019 <- Divvy_Trips_2019_2020_Q1%>% 
  filter(año == 2019) %>% 
  count()

cant_2020 <- Divvy_Trips_2019_2020_Q1%>% 
  filter(año == 2020) %>% 
  count()

dif <- cant_2020 - cant_2019
print(dif)
